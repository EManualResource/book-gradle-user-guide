# 入门

接下来的教程讲先介绍Gradle的基础知识

#### Chapter 3, 安装 Gradle

描述如何安装 Gradle.

#### Chapter 5, 脚本构建基础

介绍脚本构建的基础元素: projects 和 tasks.

#### Chapter 6, Java 快速入门

展示如何开始使用 Gradle 的合约构建来构建 Java 项目.

#### Chapter 7, 依赖管理基础

展示如何开始使用 Gradle 的依赖管理.

#### Chapter 8, Groovy 快速入门

使用 Gradle 的合约构建来构建 Groovy 项目.

#### Chapter 9, 网页应用快速入门

使用 Gradle 的合约构建来构建网页应用项目.

