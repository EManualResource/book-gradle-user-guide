# 解压缩

Gradle 发布的版本为 ****ZIP 格式. 所有文件包含:

* Gradle 的二进制文件.
* 用户指南 (HTML 和 PDF).
* DSL参考指南.
* API文档 (Javadoc和 Groovydoc).
* 扩展的例子,包括用户指南中引用的实例，以及一些更复杂的实例来帮助用户构建自己的build.
* 二进制源码.此代码仅供参考.
