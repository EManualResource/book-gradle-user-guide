# 运行并测试您的安装

您可以通过 **gradle** 命令来运行Gradle. 通过 **gradle -v** 命令来检测Gradle是否已经正确安装. 如果正确安装，会输出Gradle版本信息以及本地的配置环境  ( groovy 和 JVM 版本等). 显示的版本信息应该与您所下载的gradle版本信息相匹配.

