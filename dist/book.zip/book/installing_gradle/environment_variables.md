# 环境变量

1. 添加一个 **GRADLE_HOME** 环境变量来指明 Gradle 的安装路径

2. 添加 **GRADLE_HOME/bin** 到您的 *PATH* 环境变量中. 通常, 这样已经足够运行Gradle了.



